#!/usr/bin/env bash
service nginx reload