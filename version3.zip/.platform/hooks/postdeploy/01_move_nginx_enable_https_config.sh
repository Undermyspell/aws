#!/usr/bin/env bash
echo "test"
mv /tmp/nginx/https.txt /etc/nginx/conf.d/00_enable_https.conf