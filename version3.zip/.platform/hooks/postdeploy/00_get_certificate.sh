#!/usr/bin/env bash
certbot -n -d cpvote.eu-central-1.elasticbeanstalk.com certonly --nginx --agree-tos --email michael.kaiser@conplement.de